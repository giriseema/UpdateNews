package com.updatenews.www.updatenews.dashboad.presenter;

public interface ICategoryPresenter {
    void getListOfNewsChannel();
}
