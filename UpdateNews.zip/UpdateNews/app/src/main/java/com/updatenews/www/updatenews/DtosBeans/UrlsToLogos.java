package com.updatenews.www.updatenews.DtosBeans;

import java.io.Serializable;

/**
 * Created by yusatainfotech on 04-Oct-17.
 */

public class UrlsToLogos implements Serializable {
    private String small;
    private String medium;
    private String large;
}
