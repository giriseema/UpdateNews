package com.updatenews.www.updatenews.dashboad.view;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.updatenews.www.updatenews.DtosBeans.SourcesModel;
import com.updatenews.www.updatenews.R;
import com.updatenews.www.updatenews.dashboad.presenter.CategoryPresenter;
import com.updatenews.www.updatenews.utils.CommonProgressDialog;
import com.updatenews.www.updatenews.utils.ConstantClass;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener, NewsCategoryFragment.OnFragmentInteractionListener, ICategoryView {
    private static long back_pressed;
    private CategoryPresenter presenter;
    private NewsCategoryFragment allChannelFragment;
    private ArrayList<SourcesModel> golobalSourcesModelsList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        presenter = new CategoryPresenter(this);
        showProgressDialog();
        if (ConstantClass.isNetworkAvailable(this))
            presenter.getListOfNewsChannel();
        else
            Toast.makeText(this
                    , getString(R.string.no_internet_connectivity_error),
                    Toast.LENGTH_SHORT).show();
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("mailto:" + getString(R.string.email_address)));
                intent.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.subject));
                startActivity(Intent.createChooser(intent, "Send email..."));
            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public void onBackPressed() {

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            if (back_pressed + 2000 > System.currentTimeMillis()) {
                super.onBackPressed();
            } else {
                back_pressed = System.currentTimeMillis();
                Toast.makeText(getBaseContext(), "Press once again to exit!", Toast.LENGTH_SHORT).show();
                back_pressed = System.currentTimeMillis();
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_all_news) {
            addFragment(golobalSourcesModelsList);
        } else if (id == R.id.nav_science) {
            addFragment(resetChannelList(golobalSourcesModelsList, "Science-and-Nature"));
        } else if (id == R.id.nav_sports) {
            addFragment(resetChannelList(golobalSourcesModelsList, "Sports"));

        } else if (id == R.id.nav_technology) {
            addFragment(resetChannelList(golobalSourcesModelsList, "Technology"));

        } else if (id == R.id.nav_business) {
            addFragment(resetChannelList(golobalSourcesModelsList, "Business"));

        } else if (id == R.id.nav_enterainment) {
            addFragment(resetChannelList(golobalSourcesModelsList, "Entertainment"));

        } else if (id == R.id.nav_general) {
            addFragment(resetChannelList(golobalSourcesModelsList, "General"));

        } else if (id == R.id.nav_music) {
            addFragment(resetChannelList(golobalSourcesModelsList, "Music"));

        } else if (id == R.id.nav_politics) {
            addFragment(resetChannelList(golobalSourcesModelsList, "Politics"));

        } else if (id == R.id.nav_share) {
            Intent sendIntent = new Intent();
            sendIntent.setAction(Intent.ACTION_SEND);
            sendIntent.putExtra(Intent.EXTRA_TEXT, ConstantClass.APP_URL);
            sendIntent.setType("text/plain");
            startActivity(sendIntent);
        } else if (id == R.id.nav_send) {
            ShareAppLinkFragment shareAppLinkFragment = new ShareAppLinkFragment();
            getSupportFragmentManager().beginTransaction().replace(R.id.container_fragment, shareAppLinkFragment).commit();
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private ArrayList<SourcesModel> resetChannelList(ArrayList<SourcesModel> oldSourceList, String resetKey) {
        ArrayList<SourcesModel> resetList = new ArrayList<>();
        for (SourcesModel sourcesModel : oldSourceList) {
            if (sourcesModel.getCategory().equalsIgnoreCase(resetKey)) {
                resetList.add(sourcesModel);
            }
        }
        return resetList;
    }


    @Override
    public void onFragmentInteraction(Uri uri) {

    }

    @Override
    public void showProgressDialog() {
        CommonProgressDialog.showLoader(this);
    }

    @Override
    public void hideProgressDialog() {
        CommonProgressDialog.hideLoader();
    }

    @Override
    public void getChannelList(ArrayList<SourcesModel> sourcesModelsList, boolean isResult) {
        hideProgressDialog();
        golobalSourcesModelsList = new ArrayList<>();
        if (isResult && sourcesModelsList.size() > 0) {
            golobalSourcesModelsList.addAll(sourcesModelsList);
            addFragment(sourcesModelsList);
        }
    }

    void addFragment(ArrayList<SourcesModel> sourcesModelsList) {
        allChannelFragment = new NewsCategoryFragment();
        //allChannelFragment.newInstance(sourcesModelsList);
        Bundle bundle = new Bundle();
        bundle.putParcelableArrayList(ConstantClass.SOURCE_MODEL, sourcesModelsList);
        allChannelFragment.setArguments(bundle);
        getSupportFragmentManager().beginTransaction().replace(R.id.container_fragment, allChannelFragment).commit();
    }
}
