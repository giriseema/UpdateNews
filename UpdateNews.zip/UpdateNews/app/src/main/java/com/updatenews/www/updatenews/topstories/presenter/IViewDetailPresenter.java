package com.updatenews.www.updatenews.topstories.presenter;

public interface IViewDetailPresenter {
    void getDetailNewsList(String channelKey);
}
